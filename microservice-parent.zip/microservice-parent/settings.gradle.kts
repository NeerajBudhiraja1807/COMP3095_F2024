rootProject.name = "microservice-parent"

include("product-service")
include("order-service")
include("inventory-service")
include("api-gateway")