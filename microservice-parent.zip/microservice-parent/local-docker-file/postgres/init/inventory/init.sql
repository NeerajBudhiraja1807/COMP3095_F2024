CREATE DATABASE "inventory-service";
GRANT ALL PRIVILEGES ON DATABASE "inventory-service" TO "admin";
